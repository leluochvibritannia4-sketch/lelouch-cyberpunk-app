# Lelouch Cyberpunk Android App

This is an Android Studio project wrapping the supplied `index.html` in an Android WebView.

## Included
- Original neon cyberpunk timetable/dashboard design.
- JavaScript enabled and DOM storage enabled for persistent `localStorage` data (tasks, classes, theme).
- Theme toggle, timetable day selector, add-class form, task add/complete/delete, export JSON, clear tasks, and reset data.
- Portrait orientation and compact-height CSS tuning.

## Build an APK
An Android SDK and Gradle are required; this environment did not have the Android SDK/Gradle installed, so an APK could not be compiled here.

1. Install Android Studio on a computer.
2. Open this folder (`LelouchCyberpunkAndroid`) as a project.
3. Let Android Studio sync/download the Android Gradle Plugin and SDK platform 35.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.

Data is stored locally on the device. It remains after closing/reopening the app, but clearing app storage or uninstalling the app can erase it. Export creates a JSON backup.
